export const WORLD_SIZE = 9;
export const TILE_ASPECT_RATIO = 1 / 0.75;
export const WATER_TILES_Y_INDEXES = [1, 2];
